/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package objek_orang;

import java.awt.geom.*;
import java.awt.*;

/**
 *
 * @author RECKY
 */
public class Objek_Orang extends Panel{
    Font f;
    String text = "Hai, Semua";
    Objek_Orang(){
        setBackground(Color.white);
    }
    
    public void paint(Graphics g) {
        super.paint(g);
        Graphics2D gd = (Graphics2D) g;
        Shape atas = new Rectangle2D.Double(0, 0, 1020, 580);
        GradientPaint paint = new GradientPaint(400, 300, new Color(100, 250, 255), 500, 0, Color.blue);
        gd.setPaint(paint);
        gd.fill(atas);
        
        //rambut
        g.setColor(new Color(98,52,18));
        g.fillRoundRect(175, 60, 70, 60, 50, 100);       
        
        //kepala
        g.setColor(Color.YELLOW);
        g.fillOval(175, 70, 70, 70);
        
        //mata kiri
        g.setColor(Color.WHITE);
        g.fillOval(185, 90, 23, 18);
        g.setColor(Color.BLACK);
        g.fillOval(192,95,8 ,8);

        //mata kanan
        g.setColor(Color.WHITE);
        g.fillOval(215, 90, 23, 18);
        g.setColor(Color.BLACK);
        g.fillOval(222,95,8 ,8);
    
        //mulut
        g.setColor(Color.RED);
        g.fillOval(195,118,30 ,15);
        g.setColor(Color.WHITE);
        g.fillOval(200,118,20 ,5);       
        
        //leher
        g.setColor(Color.YELLOW);
        g.fillRect(203, 138, 15, 20);
        
        //kaki
        g.setColor(Color.YELLOW);
        g.fillArc(178, 320, 15, 25, -180,360);
        g.setColor(Color.YELLOW);
        g.fillArc(228, 320, 15, 25, -180,360);  
        
        //celana
        g.setColor(Color.black);
        g.fillRect(175, 255, 70, 70);
        
        //segitiga
        g.setColor(new Color(100, 250, 255));
        int[] x5 = {195, 210, 225};
        int[] y5 = {325, 280, 325};
        Polygon pol5 = new Polygon(x5, y5, 3);
        g.fillPolygon(pol5);
        
        //baju
        g.setColor(Color.white);
        g.fillRoundRect(160, 158, 100, 100, 20, 60);        
        g.setColor(Color.black);
        g.drawLine(210, 170, 210, 185);
        g.drawLine(210, 190, 210, 205);
        g.drawLine(210, 210, 210, 225);
        g.drawLine(210, 230, 210, 245);
        g.setColor(Color.DARK_GRAY);
        g.fillRect(230,170,20,20 );
        g.setColor(Color.white);
        g.fillArc(230, 160, 20, 20, 180, 180);
        g.setColor(Color.DARK_GRAY);
        g.drawLine(231, 170, 248, 170);
        
        //tangan
        g.setColor(Color.YELLOW);
        int[] x1 = {280,315,300,280};
        int[] y1 = {195,215,220,210};
        Polygon pol1 = new Polygon(x1, y1, 4);
        g.fillPolygon(pol1);
        int[] x4 = {110, 135, 140, 125};
        int[] y4 = {220, 200, 215, 225};
        Polygon pol4 = new Polygon(x4, y4, 4);
        g.fillPolygon(pol4);
        
        //lengan kiri
        g.setColor(Color.white);
        int[] x3 = {130, 165, 165, 140};
        int[] y3 = {200, 170, 200, 220};      
        Polygon pol3 = new Polygon(x3, y3, 4);
        g.fillPolygon(pol3);
        
        //lengan kanan
        g.setColor(Color.white);
        int[] x2 = {255, 290, 280, 255};
        int[] y2 = {170, 195, 215, 198};      
        Polygon pol2 = new Polygon(x2, y2, 4);
        g.fillPolygon(pol2);     
        
        //komentar
        g.setColor(Color.white);
        g.fillRoundRect(290, 50, 130, 50, 20, 60);
        int[] x6 = {265, 295, 295};
        int[] y6 = {100, 75, 90};      
        Polygon pol6 = new Polygon(x6, y6, 3);
        g.fillPolygon(pol6);
        
        f = new Font("Times New Roman",Font.BOLD + Font.ITALIC,22);
        g.setFont(f);
        g.setColor(Color.black);
        g.drawString(text, 300, 80);   
        
    }
    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        Frame f = new Frame("Objek Orang");
        Objek_Orang o = new Objek_Orang();
        f.add(o);
        f.setSize(550, 450);
        f.setVisible(true);       
    }
    
}
